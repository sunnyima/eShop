const app = new Vue ({
	el: '#app',
	data: {
		num: 0
	},
	methods: {
		some () {
			console.log ('from Global');
		}
	}
})