//GLOBAL

Vue.component ('el-comp', {
	data () {
		return {
			counterInner: 0,
		}
	},
	methods: {
		minus (counterInner) {
			console.log('ok');
			counterInner--;
		},
		some (index) {
			console.log(`Из ребенка прилетело:`);
			//console.log(`Из ребенка прилетело: ${index}`)
		}
	},
	props: ['somename', 'counter'],
	template: `<div>
		<h1>Hello {{ somename }}</h1>
		<p> {{ counter }} </p>
		<p> from within: {{ counterInner }} </p>
		<button @click="counter++"> Just Do It </button>
		<button @click="$emit('decrease')"> Just Do Min </button>
		<button @click="minus"> Minus within </button>
		<br>
		<child-comp></child-comp>
	</div>`
});

Vue.component ('child-comp', {
	data () {
		return {
			index: 100
		}
	},
	methods: {
		sayHi () {
			console.log(this)
		}
	},
	template: `
			<button @click="$parent.$emit('some', index)">ChildButton</button>
	`
})

